# Tathastu-TASK-2
core-java 10 basic programs
